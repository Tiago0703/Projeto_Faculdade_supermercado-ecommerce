import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  ShoppingCart, 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  Star, 
  Filter,
  Home,
  Package,
  CreditCard,
  CheckCircle,
  ArrowLeft,
  MapPin,
  Clock,
  Phone
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import './App.css'

// Mock data para produtos
const mockProducts = [
  {
    id: 1,
    name: 'Arroz Branco 5kg',
    price: 18.90,
    category: 'grãos',
    image: '/api/placeholder/200/200',
    description: 'Arroz branco tipo 1, grãos longos e soltos',
    rating: 4.5,
    inStock: true,
    discount: 10
  },
  {
    id: 2,
    name: 'Feijão Preto 1kg',
    price: 7.50,
    category: 'grãos',
    image: '/api/placeholder/200/200',
    description: 'Feijão preto selecionado, rico em proteínas',
    rating: 4.3,
    inStock: true
  },
  {
    id: 3,
    name: 'Leite Integral 1L',
    price: 4.20,
    category: 'laticínios',
    image: '/api/placeholder/200/200',
    description: 'Leite integral pasteurizado, fonte de cálcio',
    rating: 4.7,
    inStock: true
  },
  {
    id: 4,
    name: 'Pão de Forma Integral',
    price: 5.80,
    category: 'padaria',
    image: '/api/placeholder/200/200',
    description: 'Pão de forma integral, rico em fibras',
    rating: 4.2,
    inStock: true,
    discount: 15
  },
  {
    id: 5,
    name: 'Banana Nanica 1kg',
    price: 3.90,
    category: 'frutas',
    image: '/api/placeholder/200/200',
    description: 'Banana nanica fresca, rica em potássio',
    rating: 4.6,
    inStock: true
  },
  {
    id: 6,
    name: 'Tomate 1kg',
    price: 6.50,
    category: 'verduras',
    image: '/api/placeholder/200/200',
    description: 'Tomate fresco para saladas e molhos',
    rating: 4.1,
    inStock: false
  },
  {
    id: 7,
    name: 'Frango Congelado 1kg',
    price: 12.90,
    category: 'carnes',
    image: '/api/placeholder/200/200',
    description: 'Frango congelado, corte especial',
    rating: 4.4,
    inStock: true
  },
  {
    id: 8,
    name: 'Detergente 500ml',
    price: 2.80,
    category: 'limpeza',
    image: '/api/placeholder/200/200',
    description: 'Detergente concentrado, remove gordura',
    rating: 4.0,
    inStock: true
  }
]

const categories = [
  { id: 'todos', name: 'Todos os Produtos', icon: Package },
  { id: 'grãos', name: 'Grãos e Cereais', icon: Package },
  { id: 'laticínios', name: 'Laticínios', icon: Package },
  { id: 'padaria', name: 'Padaria', icon: Package },
  { id: 'frutas', name: 'Frutas', icon: Package },
  { id: 'verduras', name: 'Verduras', icon: Package },
  { id: 'carnes', name: 'Carnes', icon: Package },
  { id: 'limpeza', name: 'Limpeza', icon: Package }
]

function App() {
  const [currentPage, setCurrentPage] = useState('home')
  const [products] = useState(mockProducts)
  const [cart, setCart] = useState([])
  const [selectedCategory, setSelectedCategory] = useState('todos')
  const [searchTerm, setSearchTerm] = useState('')
  const [checkoutData, setCheckoutData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    paymentMethod: ''
  })

  // Filtrar produtos
  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'todos' || product.category === selectedCategory
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  // Funções do carrinho
  const addToCart = (product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id)
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prevCart, { ...product, quantity: 1 }]
    })
  }

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(productId)
      return
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      )
    )
  }

  const removeFromCart = (productId) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId))
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => {
      const price = item.discount ? item.price * (1 - item.discount / 100) : item.price
      return total + (price * item.quantity)
    }, 0)
  }

  const handleCheckout = () => {
    if (cart.length === 0) return
    setCurrentPage('checkout')
  }

  const handleOrderComplete = () => {
    setCart([])
    setCurrentPage('success')
  }

  // Componente Header
  const Header = () => (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <motion.div
              className="text-2xl font-bold text-green-600 cursor-pointer"
              onClick={() => setCurrentPage('home')}
              whileHover={{ scale: 1.05 }}
            >
              🛒 Fresh Market
            </motion.div>
          </div>

          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => setCurrentPage('home')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                currentPage === 'home' ? 'bg-green-100 text-green-700' : 'hover:bg-gray-100'
              }`}
            >
              <Home className="h-4 w-4" />
              <span>Início</span>
            </button>
            <button
              onClick={() => setCurrentPage('products')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                currentPage === 'products' ? 'bg-green-100 text-green-700' : 'hover:bg-gray-100'
              }`}
            >
              <Package className="h-4 w-4" />
              <span>Produtos</span>
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage('cart')}
              className="relative"
            >
              <ShoppingCart className="h-4 w-4" />
              {getTotalItems() > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {getTotalItems()}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  )

  // Componente Home
  const HomePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Bem-vindo ao
              <span className="text-green-600 block">Fresh Market</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Produtos frescos e de qualidade entregues na sua casa. 
              Compre online com praticidade e segurança.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => setCurrentPage('products')}
                className="bg-green-600 hover:bg-green-700"
              >
                Ver Produtos
                <Package className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setCurrentPage('cart')}
              >
                Meu Carrinho ({getTotalItems()})
                <ShoppingCart className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categorias em Destaque */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Nossas Categorias
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.slice(1, 5).map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center cursor-pointer group"
                onClick={() => {
                  setSelectedCategory(category.id)
                  setCurrentPage('products')
                }}
              >
                <div className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-200 transition-colors">
                  <category.icon className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 group-hover:text-green-600 transition-colors">
                  {category.name}
                </h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Produtos em Destaque */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Ofertas Especiais
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.filter(p => p.discount).map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <div className="w-full h-48 bg-gray-100 flex items-center justify-center">
                      <Package className="h-16 w-16 text-gray-400" />
                    </div>
                    {product.discount && (
                      <Badge className="absolute top-2 right-2 bg-red-500">
                        -{product.discount}%
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {product.discount ? (
                          <>
                            <span className="text-lg font-bold text-green-600">
                              R$ {(product.price * (1 - product.discount / 100)).toFixed(2)}
                            </span>
                            <span className="text-sm text-gray-500 line-through">
                              R$ {product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="text-lg font-bold text-green-600">
                            R$ {product.price.toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button 
                      className="w-full bg-green-600 hover:bg-green-700"
                      onClick={() => addToCart(product)}
                      disabled={!product.inStock}
                    >
                      {product.inStock ? 'Adicionar' : 'Indisponível'}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )

  // Componente Products
  const ProductsPage = () => (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Filtros e Busca */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar produtos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-80"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Grid de Produtos */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
                <div className="relative">
                  <div className="w-full h-48 bg-gray-100 flex items-center justify-center">
                    <Package className="h-16 w-16 text-gray-400" />
                  </div>
                  {product.discount && (
                    <Badge className="absolute top-2 right-2 bg-red-500">
                      -{product.discount}%
                    </Badge>
                  )}
                  {!product.inStock && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <Badge variant="destructive">Indisponível</Badge>
                    </div>
                  )}
                </div>
                <CardContent className="p-4 flex flex-col h-full">
                  <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 flex-grow">{product.description}</p>
                  
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 ml-2">({product.rating})</span>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    {product.discount ? (
                      <div className="flex flex-col">
                        <span className="text-lg font-bold text-green-600">
                          R$ {(product.price * (1 - product.discount / 100)).toFixed(2)}
                        </span>
                        <span className="text-sm text-gray-500 line-through">
                          R$ {product.price.toFixed(2)}
                        </span>
                      </div>
                    ) : (
                      <span className="text-lg font-bold text-green-600">
                        R$ {product.price.toFixed(2)}
                      </span>
                    )}
                  </div>

                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => addToCart(product)}
                    disabled={!product.inStock}
                  >
                    {product.inStock ? (
                      <>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar
                      </>
                    ) : (
                      'Indisponível'
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Nenhum produto encontrado
            </h3>
            <p className="text-gray-600">
              Tente ajustar os filtros ou termo de busca
            </p>
          </div>
        )}
      </div>
    </div>
  )

  // Componente Cart
  const CartPage = () => (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-8">
          <Button
            variant="ghost"
            onClick={() => setCurrentPage('products')}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Continuar Comprando
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Meu Carrinho</h1>
        </div>

        {cart.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Seu carrinho está vazio
            </h3>
            <p className="text-gray-600 mb-6">
              Adicione alguns produtos para começar suas compras
            </p>
            <Button 
              onClick={() => setCurrentPage('products')}
              className="bg-green-600 hover:bg-green-700"
            >
              Ver Produtos
            </Button>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Lista de Produtos */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Produtos no Carrinho</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cart.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      className="flex items-center space-x-4 p-4 border rounded-lg"
                    >
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                        <Package className="h-8 w-8 text-gray-400" />
                      </div>
                      
                      <div className="flex-grow">
                        <h3 className="font-semibold text-gray-900">{item.name}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          {item.discount ? (
                            <>
                              <span className="font-bold text-green-600">
                                R$ {(item.price * (1 - item.discount / 100)).toFixed(2)}
                              </span>
                              <span className="text-sm text-gray-500 line-through">
                                R$ {item.price.toFixed(2)}
                              </span>
                            </>
                          ) : (
                            <span className="font-bold text-green-600">
                              R$ {item.price.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-8 text-center font-semibold">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Resumo do Pedido */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Resumo do Pedido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal ({getTotalItems()} itens)</span>
                    <span>R$ {getTotalPrice().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de entrega</span>
                    <span className="text-green-600">Grátis</span>
                  </div>
                  <hr />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-green-600">R$ {getTotalPrice().toFixed(2)}</span>
                  </div>
                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={handleCheckout}
                  >
                    Finalizar Compra
                    <CreditCard className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )

  // Componente Checkout
  const CheckoutPage = () => (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-8">
          <Button
            variant="ghost"
            onClick={() => setCurrentPage('cart')}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar ao Carrinho
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Finalizar Compra</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Formulário de Checkout */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Informações de Entrega</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nome Completo
                    </label>
                    <Input
                      value={checkoutData.name}
                      onChange={(e) => setCheckoutData({...checkoutData, name: e.target.value})}
                      placeholder="Seu nome completo"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Telefone
                    </label>
                    <Input
                      value={checkoutData.phone}
                      onChange={(e) => setCheckoutData({...checkoutData, phone: e.target.value})}
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <Input
                    type="email"
                    value={checkoutData.email}
                    onChange={(e) => setCheckoutData({...checkoutData, email: e.target.value})}
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Endereço Completo
                  </label>
                  <Textarea
                    value={checkoutData.address}
                    onChange={(e) => setCheckoutData({...checkoutData, address: e.target.value})}
                    placeholder="Rua, número, bairro, cidade, CEP"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Método de Pagamento
                  </label>
                  <Select 
                    value={checkoutData.paymentMethod} 
                    onValueChange={(value) => setCheckoutData({...checkoutData, paymentMethod: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o método de pagamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="cartao">Cartão de Crédito</SelectItem>
                      <SelectItem value="dinheiro">Dinheiro na Entrega</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Resumo Final */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.name} x{item.quantity}</span>
                      <span>R$ {((item.discount ? item.price * (1 - item.discount / 100) : item.price) * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <hr />
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span className="text-green-600">R$ {getTotalPrice().toFixed(2)}</span>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center text-green-700 mb-2">
                    <Clock className="h-4 w-4 mr-2" />
                    <span className="font-semibold">Entrega Grátis</span>
                  </div>
                  <p className="text-sm text-green-600">
                    Entrega em até 2 horas úteis
                  </p>
                </div>

                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={handleOrderComplete}
                  disabled={!checkoutData.name || !checkoutData.email || !checkoutData.address || !checkoutData.paymentMethod}
                >
                  Confirmar Pedido
                  <CheckCircle className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )

  // Componente Success
  const SuccessPage = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-8">
      <div className="max-w-md mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Pedido Confirmado!
          </h1>
          
          <p className="text-gray-600 mb-8">
            Seu pedido foi recebido e está sendo preparado. 
            Você receberá uma confirmação por email em breve.
          </p>

          <div className="bg-white p-6 rounded-lg border mb-8">
            <div className="flex items-center justify-center text-green-700 mb-4">
              <Clock className="h-5 w-5 mr-2" />
              <span className="font-semibold">Tempo estimado de entrega</span>
            </div>
            <p className="text-2xl font-bold text-green-600">1-2 horas</p>
          </div>

          <div className="space-y-3">
            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => setCurrentPage('home')}
            >
              Voltar ao Início
              <Home className="ml-2 h-4 w-4" />
            </Button>
            
            <Button 
              variant="outline"
              className="w-full"
              onClick={() => setCurrentPage('products')}
            >
              Continuar Comprando
              <Package className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <AnimatePresence mode="wait">
        {currentPage === 'home' && <HomePage key="home" />}
        {currentPage === 'products' && <ProductsPage key="products" />}
        {currentPage === 'cart' && <CartPage key="cart" />}
        {currentPage === 'checkout' && <CheckoutPage key="checkout" />}
        {currentPage === 'success' && <SuccessPage key="success" />}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">🛒 Fresh Market</h3>
              <p className="text-gray-400">
                Produtos frescos e de qualidade entregues na sua casa.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  <span>(11) 99999-9999</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>São Paulo, SP</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Horário de Funcionamento</h4>
              <div className="text-gray-400">
                <p>Segunda a Sábado: 8h às 22h</p>
                <p>Domingo: 8h às 18h</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Fresh Market. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
